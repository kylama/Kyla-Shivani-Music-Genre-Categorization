DevContainer and other configuration for developing Flask projects
with GitHub Codespaces
